#include "Database.h"
#include "Parser.h"

class Interpreter {
private:
  Database database;
  DatalogProgram datalogProgram;
  map<string, int> something;

public:
  void evaluateSchemes() {
    vector<Predicate> schemes = datalogProgram.getSchemes();
    // for loop schemes -> scheme
    for (auto &scheme : schemes) {
      database.add_relation(scheme.getName(), scheme.parametersAsStrings());
    }
  }

  void evaluteFacts() {
    // add getFacts (similar to getSchemes) to datalogProgram
    vector<Predicate> facts = datalogProgram.getFacts();
    // for loop facts -> fact
    for (auto &fact : facts) {
      database.add_relation(fact.getName(), fact.parametersAsStrings());
    }
  }

  void evaluateQueries() {
    vector<Predicate> queries = datalogProgram.getQueries();
    // for loop quieres -> query
    for (auto &query : queries) {
      string tableName = query.getName();
      vector<Parameter> columnQueries = query.getParameters();
      // for loop using indexes for(i = 0, ...)
      for (int i = 0; i < columnQueries.size(); i++) {
        Relation relation = database.get_relation(tableName);
        // this is for constant
        if (columnQueries[i].isConstant) {
          relation.select(i, columnQueries[i].toString());
        }
        // else this is not a constant
        relation.select(i)
      }
    }
  }
};