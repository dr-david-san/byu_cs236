#include "Interpreter.h"
#include "Parser.h"
#include "Relation.h"
#include "Scanner.h"
#include "Scheme.h"
#include "Token.h"
#include "Tuple.h"
#include "vector"
#include <fstream>
#include <iostream>
#include <sstream>

using namespace std;

int main(int argc, char *argv[]) {
  std::string filename = argv[1];
  std::ifstream in;
  in.open(filename);
  std::stringstream ss;
  ss << in.rdbuf();
  std::string input = ss.str();
  in.close();
  Scanner s = Scanner(input);

  std::vector<Token> vecToken = s.scanToken();

  Parser p = Parser(vecToken);
  DatalogProgram output = p.parse();
  if (output.wasSuccess()) {
    cout << output.toString() << endl;
  }

  // vector<string> names = {"ID", "Name", "Major"};

  // Scheme scheme(names);

  // Relation relation("student", scheme);

  // vector<string> values[] = {
  //     {"'42'", "'Ann'", "'CS'"},
  //     {"'32'", "'Bob'", "'CS'"},
  //     {"'64'", "'Ned'", "'EE'"},
  //     {"'16'", "'Jim'", "'EE'"},
  // };

  // for (auto &value : values) {
  //   Tuple tuple(value);
  //   cout << tuple.toString(scheme) << endl;
  //   relation.addTuple(tuple);
  // }

  // cout << "relation:" << endl;
  // cout << relation.toString();

  // Relation result = relation.select(2, "'CS'");

  // cout << "select Major='CS' result:" << endl;
  // cout << result.toString();
}