#pragma once
#include "Parser.h"
#include "Scheme.h"
#include "Tuple.h"
#include <cctype>
#include <set>
#include <string>
#include <vector>

class Relation {

private:
  string name;
  Scheme scheme;
  set<Tuple> tuples;

public:
  Relation(const string &name, const Scheme &scheme)
      : name(name), scheme(scheme) {}

  void addTuple(const Tuple &tuple) { tuples.insert(tuple); }

  string toString() const {
    stringstream out;
    // add code to print the Tuples, one per line
    for (const auto &tuple : tuples) {
      out << tuple.toString(scheme) << "\n";
    }
    return out.str();
  }

  Relation select(int index, const string &value) const {
    Relation result(name, scheme);
    // add tuples to the result if they meet the condition
    for (const auto &tuple : tuples) {
      if (tuple.at(index) == value) {
        result.addTuple(tuple);
      }
    }
    return result;
  }

  // todo: (select, project, and rename)
};